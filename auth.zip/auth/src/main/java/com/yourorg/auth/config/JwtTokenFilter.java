package com.yourorg.auth.config;

import com.yourorg.auth.service.UserService;
import io.jsonwebtoken.JwtException;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

@Component
public class JwtTokenFilter extends OncePerRequestFilter {

    private final UserService userService;

    public JwtTokenFilter(UserService userService) {
        this.userService = userService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        String header = request.getHeader(HttpHeaders.AUTHORIZATION);
        if (header != null && header.startsWith("Bearer ")) {
            String token = header.substring(7);
            try {
                UUID userId = userService.validateAndGetUserIdFromToken(token);
                // For simplicity: load claims to extract role
                var claims = io.jsonwebtoken.Jwts.parserBuilder()
                        .setSigningKey(io.jsonwebtoken.security.Keys.hmacShaKeyFor(
                                System.getenv().getOrDefault("JWT_SECRET", "default-key-that-is-too-short-change-me123456")))
                        .build()
                        .parseClaimsJws(token)
                        .getBody();

                String role = (String) claims.get("role");
                var auth = new UsernamePasswordAuthenticationToken(
                        userId, null, List.of(new SimpleGrantedAuthority("ROLE_" + role))
                );
                SecurityContextHolder.getContext().setAuthentication(auth);
            } catch (JwtException | IllegalArgumentException e) {
                // invalid token -> do nothing, request will be unauthenticated
            }
        }
        filterChain.doFilter(request, response);
    }
}
