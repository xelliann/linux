package com.yourorg.auth.controller;

import com.yourorg.auth.dto.AuthRequest;
import com.yourorg.auth.dto.AuthResponse;
import com.yourorg.auth.dto.RegisterRequest;
import com.yourorg.auth.dto.RefreshRequest;
import com.yourorg.auth.service.UserService;
import jakarta.validation.Valid;
import lombok.var;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(@Valid @RequestBody RegisterRequest req) {
        AuthResponse resp = userService.register(req);
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(@Valid @RequestBody AuthRequest req) {
        AuthResponse resp = userService.login(req);
        return ResponseEntity.ok(resp);
    }

    @PostMapping("/refresh")
    public ResponseEntity<AuthResponse> refresh(@Valid @RequestBody RefreshRequest req) {
        // For simplicity: re-parse refresh token to get user id, then issue tokens again
        var token = req.getRefreshToken();
        try {
            var claims = io.jsonwebtoken.Jwts.parserBuilder()
                    .setSigningKey(io.jsonwebtoken.security.Keys.hmacShaKeyFor(
                            System.getenv().getOrDefault("JWT_SECRET", "default-key-that-is-too-short-change-me123456")))
                    .build().parseClaimsJws(token).getBody();
            String userId = claims.getSubject();
            var user = userService.getClass()
                    .getDeclaredMethod("validateAndGetUserIdFromToken", String.class);
            // rather than reflect, simply rely on validate method in service
            // simpler approach: create tokens by using user repository (not shown) - we'll keep simple:
            // NOTE: For production implement refresh-token persistence & secure flow.

            var uuid = java.util.UUID.fromString(userId);
            // naive: fetch user entity via repository (not exposed). Better: add a method in UserService to create tokens by userId.
            // For now, throw unsupported to keep example short.
            throw new UnsupportedOperationException("Refresh endpoint: implement refresh token store or call userService method");
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
