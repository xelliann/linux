package com.yourorg.auth.service;

import com.yourorg.auth.dto.AuthRequest;
import com.yourorg.auth.dto.AuthResponse;
import com.yourorg.auth.dto.RegisterRequest;
import com.yourorg.auth.model.User;
import com.yourorg.auth.repository.UserRepository;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.security.Key;
import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final Key signingKey;
    private final long accessTokenMs;
    private final long refreshTokenMs;

    public UserService(UserRepository userRepository,
                       PasswordEncoder passwordEncoder,
                       @Value("${app.jwt.secret}") String jwtSecret,
                       @Value("${app.jwt.access-ms:900000}") long accessTokenMs,
                       @Value("${app.jwt.refresh-ms:1209600000}") long refreshTokenMs) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.signingKey = Keys.hmacShaKeyFor(jwtSecret.getBytes());
        this.accessTokenMs = accessTokenMs;
        this.refreshTokenMs = refreshTokenMs;
    }

    public AuthResponse register(RegisterRequest req) {
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new RuntimeException("Email already registered");
        }
        User user = User.builder()
                .id(UUID.randomUUID())
                .name(req.getName())
                .email(req.getEmail())
                .passwordHash(passwordEncoder.encode(req.getPassword()))
                .role(req.getRole() == null ? "CUSTOMER" : req.getRole())
                .createdAt(Instant.now())
                .build();
        userRepository.save(user);
        return createTokens(user);
    }

    public AuthResponse login(AuthRequest req) {
        User user = userRepository.findByEmail(req.getEmail())
                .orElseThrow(() -> new RuntimeException("Invalid credentials"));
        if (!passwordEncoder.matches(req.getPassword(), user.getPasswordHash())) {
            throw new RuntimeException("Invalid credentials");
        }
        return createTokens(user);
    }

    private AuthResponse createTokens(User user) {
        Instant now = Instant.now();
        String accessToken = Jwts.builder()
                .setSubject(user.getId().toString())
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(now.plusMillis(accessTokenMs)))
                .addClaims(Map.of("role", user.getRole(), "email", user.getEmail()))
                .signWith(signingKey)
                .compact();

        String refreshToken = Jwts.builder()
                .setSubject(user.getId().toString())
                .setIssuedAt(Date.from(now))
                .setExpiration(Date.from(now.plusMillis(refreshTokenMs)))
                .addClaims(Map.of("type", "refresh"))
                .signWith(signingKey)
                .compact();

        return new AuthResponse(accessToken, refreshToken);
    }

    public UUID validateAndGetUserIdFromToken(String token) {
        Jws<Claims> claims = Jwts.parserBuilder().setSigningKey(signingKey).build().parseClaimsJws(token);
        String sub = claims.getBody().getSubject();
        return UUID.fromString(sub);
    }
}
